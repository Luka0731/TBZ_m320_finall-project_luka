package ch.tbz.bookarchive.domain.user;

import ch.tbz.bookarchive.domain.user.dto.UserDTO;
import ch.tbz.bookarchive.domain.user.dto.UserMapper;
import ch.tbz.bookarchive.domain.user.dto.UserSignupDTO;
import ch.tbz.bookarchive.domain.user.dto.UserUpdateDTO;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.UUID;

@Validated
@RestController
@RequestMapping("/user")
public class UserController {
    private final UserService userService;
    private final UserMapper userMapper;

    @Autowired
    public UserController(UserService userService, UserMapper userMapper) {
        this.userService = userService;
        this.userMapper = userMapper;
    }

    @GetMapping("/{id}")
    @Operation(summary = "Show a user by id", description = "Find and show a user by id")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<UserDTO> retrieveById(@PathVariable UUID id) {
        User user = userService.findById(id);
        return new ResponseEntity<>(userMapper.toDTO(user), HttpStatus.OK);
    }

    @GetMapping({"", "/"})
    @Operation(summary = "Show all users", description = "Show all existing users")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<List<UserDTO>> retrieveAll() {
        List<User> users = userService.findAll();
        return new ResponseEntity<>(userMapper.toDTOs(users), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a user by id", description = "Update a certain user by id")
    @PreAuthorize("isAuthenticated() && @userPermissionEvaluator.isSelf(authentication.principal.user, #id)")
    public ResponseEntity<UserDTO> updateById(@PathVariable UUID id, @Valid @RequestBody UserUpdateDTO userUpdateDTO) {
        User user = userService.findById(id);
        user.setUserName(userUpdateDTO.getUserName());
        user = userService.save(user);
        return new ResponseEntity<>(userMapper.toDTO(user), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a user", description = "Delete a certain user by id")
    @PreAuthorize("isAuthenticated() && @userPermissionEvaluator.isSelf(authentication.principal.user, #id)")
    public ResponseEntity<Void> deleteById(@PathVariable UUID id) {
        userService.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PatchMapping("/{userId}/likes-book/{bookId}")
    @Operation(summary = "Toggle book like", description = "Like if not liked, unlike if already liked")
    @PreAuthorize("isAuthenticated() && @userPermissionEvaluator.isSelf(authentication.principal.user, #userId)")
    public ResponseEntity<UserDTO> toggleLikeBook(@PathVariable UUID userId, @PathVariable UUID bookId) {
        User user = userService.toggleLikeBook(userId, bookId);
        return new ResponseEntity<>(userMapper.toDTO(user), HttpStatus.OK);
    }


    // |--- authentication stuff ---/

    @PostMapping("/signup")
    @Operation(summary = "Create a new user", description = "Create a new user with a password")
    public ResponseEntity<UserDTO> signup(@Valid @RequestBody UserSignupDTO userRegisterDTO) {
        User user = userService.signup(userMapper.fromUserRegisterDTO(userRegisterDTO));
        return new ResponseEntity<>(userMapper.toDTO(user), HttpStatus.CREATED);
    }
}
